from django.apps import AppConfig


class GdataConfig(AppConfig):
    name = 'GData'
